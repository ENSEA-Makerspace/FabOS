<?php
namespace App\Controller;

use App\Entity\Utilisateur;
use App\Entity\Badge;
use App\Entity\UtilisateurBadge;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class TestController extends AbstractController
{
    #[Route('/test', name: 'app_test')]
    public function test(EntityManagerInterface $em): Response
    {
        // Créer un badge
        $badge = new Badge();
        $badge->setNom('Développeur Symfony');
        $badge->setNiveau(1);

        // Créer un utilisateur
        $user = new Utilisateur();
        $user->setEmail('test@example.com');
        $user->setUsername('testuser');
        $user->setPassword('password');

        // Lier le badge à l'utilisateur
        $userBadge = new UtilisateurBadge();
        $userBadge->setUtilisateur($user);
        $userBadge->setBadge($badge);

        // Sauvegarder en base
        $em->persist($badge);
        $em->persist($user);
        $em->persist($userBadge);
        $em->flush();

        return $this->json([
            'success' => true,
            'badge_id' => $badge->getId(),
            'user_id' => $user->getId(),
            'message' => '✅ Tout fonctionne !'
        ]);
    }
}
