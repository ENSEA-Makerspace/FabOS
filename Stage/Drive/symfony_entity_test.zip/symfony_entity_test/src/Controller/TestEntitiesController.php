<?php
namespace App\Controller;

use App\Entity\Utilisateur;
use App\Entity\Badge;
use App\Entity\Machine;
use App\Entity\Formation;
use App\Entity\UtilisateurBadge;
use App\Entity\UtilisateurFormation;
use App\Entity\Reservation;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class TestEntitiesController extends AbstractController
{
    #[Route('/test-entities', name: 'app_test_entities')]
    public function test(EntityManagerInterface $em): Response
    {
        // 1. Créer un badge
        $badge = new Badge();
        $badge->setNom('Développeur Symfony');
        $badge->setNiveau(2);
        $badge->setDescription('Maîtrise de Symfony 7');
        $em->persist($badge);

        // 2. Créer un utilisateur
        $user = new Utilisateur();
        $user->setEmail('test2@example.com');
        $user->setUsername('johndoe');
        $user->setPassword('password123');
        $em->persist($user);

        // 3. Créer une machine
        $machine = new Machine();
        $machine->setNom('Serveur Dev');
        $machine->setStatut('actif');
        $machine->setMachineToken('dev-server-002');
        $em->persist($machine);

        // 4. Créer une formation
        $formation = new Formation();
        $formation->setTitre('Symfony Avancé');
        $formation->setDurée(180);
        $formation->setBadge($badge);
        $em->persist($formation);

        // 5. Lier utilisateur et badge
        $userBadge = new UtilisateurBadge();
        $userBadge->setUtilisateur($user);
        $userBadge->setBadge($badge);
        $em->persist($userBadge);

        // 6. Lier utilisateur et formation
        $userFormation = new UtilisateurFormation();
        $userFormation->setUtilisateur($user);
        $userFormation->setFormation($formation);
        $userFormation->setPlacePrise(1);
        $em->persist($userFormation);

        // 7. Créer une réservation
        $reservation = new Reservation();
        $reservation->setUser($user);
        $reservation->setMachine($machine);
        $reservation->setDateDebut(new \DateTime('+1 day'));
        $reservation->setDateFin(new \DateTime('+2 days'));
        $reservation->setMotif('Test technique');
        $em->persist($reservation);

        // 8. Sauvegarder tout
        $em->flush();

        return $this->json([
            'success' => true,
            'message' => 'Toutes les entités ont été créées avec succès !',
            'data' => [
                'badge_id' => $badge->getId(),
                'user_id' => $user->getId(),
                'machine_id' => $machine->getId(),
                'formation_id' => $formation->getId(),
            ]
        ]);
    }
}
