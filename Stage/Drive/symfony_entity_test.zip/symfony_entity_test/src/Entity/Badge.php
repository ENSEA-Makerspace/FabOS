<?php
// src/Entity/Badge.php
namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
class Badge
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\Column(type: 'string', length: 255)]
    private string $nom;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private ?string $catégorie = null;

    #[ORM\Column(type: 'integer', options: ['default' => 1])]
    private int $niveau = 1;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $description = null;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private ?string $icone = null;

    #[ORM\Column(type: 'datetime', options: ['default' => 'CURRENT_TIMESTAMP'])]
    private \DateTimeInterface $createdAt;

    #[ORM\OneToMany(mappedBy: 'badge', targetEntity: Formation::class)]
    private Collection $formations;

    #[ORM\ManyToMany(targetEntity: Machine::class, mappedBy: 'badges')]
    private Collection $machines;

    #[ORM\OneToMany(mappedBy: 'badge', targetEntity: UtilisateurBadge::class)]
    private Collection $utilisateurBadges;
    
    public function __construct()
    {
        $this->formations = new ArrayCollection();
        $this->machines = new ArrayCollection();
        $this->utilisateurBadges = new ArrayCollection();
        $this->createdAt = new \DateTime();
    }

    // Getters & Setters
    public function getId(): ?int { return $this->id; }
    public function getNom(): string { return $this->nom; }
    public function setNom(string $nom): self { $this->nom = $nom; return $this; }
    public function getCatégorie(): ?string { return $this->catégorie; }
    public function setCatégorie(?string $catégorie): self { $this->catégorie = $catégorie; return $this; }
    public function getNiveau(): int { return $this->niveau; }
    public function setNiveau(int $niveau): self { $this->niveau = $niveau; return $this; }
    public function getDescription(): ?string { return $this->description; }
    public function setDescription(?string $description): self { $this->description = $description; return $this; }
    public function getIcone(): ?string { return $this->icone; }
    public function setIcone(?string $icone): self { $this->icone = $icone; return $this; }
    public function getCreatedAt(): \DateTimeInterface { return $this->createdAt; }
    public function setCreatedAt(\DateTimeInterface $createdAt): self { $this->createdAt = $createdAt; return $this; }

    public function getFormations(): Collection { return $this->formations; }
    public function addFormation(Formation $formation): self { if (!$this->formations->contains($formation)) { $this->formations->add($formation); $formation->setBadge($this); } return $this; }
    public function removeFormation(Formation $formation): self { if ($this->formations->removeElement($formation)) { if ($formation->getBadge() === $this) { $formation->setBadge(null); } } return $this; }

    public function getMachines(): Collection { return $this->machines; }
    public function addMachine(Machine $machine): self { if (!$this->machines->contains($machine)) { $this->machines->add($machine); } return $this; }
    public function removeMachine(Machine $machine): self { $this->machines->removeElement($machine); return $this; }

    public function getUtilisateurBadges(): Collection { return $this->utilisateurBadges; }
    public function addUtilisateurBadge(UtilisateurBadge $utilisateurBadge): self { if (!$this->utilisateurBadges->contains($utilisateurBadge)) { $this->utilisateurBadges->add($utilisateurBadge); } return $this; }
    public function removeUtilisateurBadge(UtilisateurBadge $utilisateurBadge): self { $this->utilisateurBadges->removeElement($utilisateurBadge); return $this; }
}