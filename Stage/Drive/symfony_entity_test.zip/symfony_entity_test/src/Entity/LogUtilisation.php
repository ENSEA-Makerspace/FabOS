<?php
// src/Entity/LogUtilisation.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'LOG_UTILISATION')]
class LogUtilisation
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: Machine::class, inversedBy: 'logsUtilisation')]
    #[ORM\JoinColumn(name: 'machineId', referencedColumnName: 'id')]
    private Machine $machine;

    #[ORM\ManyToOne(targetEntity: Utilisateur::class, inversedBy: 'logsUtilisation')]
    #[ORM\JoinColumn(name: 'userId', referencedColumnName: 'id')]
    private Utilisateur $user;

    #[ORM\Column(type: 'datetime')]
    private \DateTimeInterface $dateDebut;

    #[ORM\Column(type: 'datetime', nullable: true)]
    private ?\DateTimeInterface $dateFin = null;

    #[ORM\Column(type: 'integer', nullable: true)]
    private ?int $duree = null;

    #[ORM\Column(type: 'string', length: 50, nullable: true)]
    private ?string $source = null;

    #[ORM\Column(type: 'string', length: 50, options: ['default' => 'en_cours'])]
    private string $statut = 'en_cours';

    #[ORM\Column(type: 'datetime', options: ['default' => 'CURRENT_TIMESTAMP'])]
    private \DateTimeInterface $createdAt;

    public function __construct()
    {
        $this->createdAt = new \DateTime();
    }

    // Getters & Setters
    public function getId(): ?int { return $this->id; }
    public function getMachine(): Machine { return $this->machine; }
    public function setMachine(Machine $machine): self { $this->machine = $machine; return $this; }
    public function getUser(): Utilisateur { return $this->user; }
    public function setUser(Utilisateur $user): self { $this->user = $user; return $this; }
    public function getDateDebut(): \DateTimeInterface { return $this->dateDebut; }
    public function setDateDebut(\DateTimeInterface $dateDebut): self { $this->dateDebut = $dateDebut; return $this; }
    public function getDateFin(): ?\DateTimeInterface { return $this->dateFin; }
    public function setDateFin(?\DateTimeInterface $dateFin): self { $this->dateFin = $dateFin; return $this; }
    public function getDuree(): ?int { return $this->duree; }
    public function setDuree(?int $duree): self { $this->duree = $duree; return $this; }
    public function getSource(): ?string { return $this->source; }
    public function setSource(?string $source): self { $this->source = $source; return $this; }
    public function getStatut(): string { return $this->statut; }
    public function setStatut(string $statut): self { $this->statut = $statut; return $this; }
    public function getCreatedAt(): \DateTimeInterface { return $this->createdAt; }
    public function setCreatedAt(\DateTimeInterface $createdAt): self { $this->createdAt = $createdAt; return $this; }
}