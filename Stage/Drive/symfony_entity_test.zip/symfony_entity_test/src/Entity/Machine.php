<?php
// src/Entity/Machine.php
namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
class Machine
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\Column(type: 'string', length: 255)]
    private string $nom;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $description = null;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private ?string $categorie = null;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $caracteristiques = null;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private ?string $localisation = null;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private ?string $photo = null;

    #[ORM\Column(type: 'string', length: 50)]
    private string $statut;

    #[ORM\Column(type: 'string', length: 50, nullable: true)]
    private ?string $granularite = null;

    #[ORM\Column(type: 'integer', options: ['default' => 0])]
    private int $limiteReservations = 0;

    #[ORM\Column(type: 'string', length: 255, unique: true)]
    private string $machineToken;

    #[ORM\Column(type: 'datetime', options: ['default' => 'CURRENT_TIMESTAMP'])]
    private \DateTimeInterface $createdAt;

    #[ORM\Column(type: 'datetime', options: ['default' => 'CURRENT_TIMESTAMP'])]
    private \DateTimeInterface $updated;

    #[ORM\Column(type: 'datetime', nullable: true)]
    private ?\DateTimeInterface $lastAuthorizationTime = null;

    #[ORM\ManyToMany(targetEntity: Badge::class, inversedBy: 'machines')]
    #[ORM\JoinTable(name: 'MACHINE_BADGE')]
    #[ORM\JoinColumn(name: 'machineId', referencedColumnName: 'id')]
    #[ORM\InverseJoinColumn(name: 'badgeId', referencedColumnName: 'id')]
    private Collection $badges;

    #[ORM\OneToMany(mappedBy: 'machine', targetEntity: Reservation::class)]
    private Collection $reservations;

    #[ORM\OneToMany(mappedBy: 'machine', targetEntity: LogUtilisation::class)]
    private Collection $logsUtilisation;

    public function __construct()
    {
        $this->badges = new ArrayCollection();
        $this->reservations = new ArrayCollection();
        $this->logsUtilisation = new ArrayCollection();
        $this->createdAt = new \DateTime();
        $this->updated = new \DateTime();
    }

    // Getters & Setters
    public function getId(): ?int { return $this->id; }
    public function getNom(): string { return $this->nom; }
    public function setNom(string $nom): self { $this->nom = $nom; return $this; }
    public function getDescription(): ?string { return $this->description; }
    public function setDescription(?string $description): self { $this->description = $description; return $this; }
    public function getCategorie(): ?string { return $this->categorie; }
    public function setCategorie(?string $categorie): self { $this->categorie = $categorie; return $this; }
    public function getCaracteristiques(): ?string { return $this->caracteristiques; }
    public function setCaracteristiques(?string $caracteristiques): self { $this->caracteristiques = $caracteristiques; return $this; }
    public function getLocalisation(): ?string { return $this->localisation; }
    public function setLocalisation(?string $localisation): self { $this->localisation = $localisation; return $this; }
    public function getPhoto(): ?string { return $this->photo; }
    public function setPhoto(?string $photo): self { $this->photo = $photo; return $this; }
    public function getStatut(): string { return $this->statut; }
    public function setStatut(string $statut): self { $this->statut = $statut; return $this; }
    public function getGranularite(): ?string { return $this->granularite; }
    public function setGranularite(?string $granularite): self { $this->granularite = $granularite; return $this; }
    public function getLimiteReservations(): int { return $this->limiteReservations; }
    public function setLimiteReservations(int $limiteReservations): self { $this->limiteReservations = $limiteReservations; return $this; }
    public function getMachineToken(): string { return $this->machineToken; }
    public function setMachineToken(string $machineToken): self { $this->machineToken = $machineToken; return $this; }
    public function getCreatedAt(): \DateTimeInterface { return $this->createdAt; }
    public function setCreatedAt(\DateTimeInterface $createdAt): self { $this->createdAt = $createdAt; return $this; }
    public function getUpdated(): \DateTimeInterface { return $this->updated; }
    public function setUpdated(\DateTimeInterface $updated): self { $this->updated = $updated; return $this; }
    public function getLastAuthorizationTime(): ?\DateTimeInterface { return $this->lastAuthorizationTime; }
    public function setLastAuthorizationTime(?\DateTimeInterface $lastAuthorizationTime): self { $this->lastAuthorizationTime = $lastAuthorizationTime; return $this; }

    public function getBadges(): Collection { return $this->badges; }
    public function addBadge(Badge $badge): self { if (!$this->badges->contains($badge)) { $this->badges->add($badge); $badge->addMachine($this); } return $this; }
    public function removeBadge(Badge $badge): self { if ($this->badges->removeElement($badge)) { $badge->removeMachine($this); } return $this; }

    public function getReservations(): Collection { return $this->reservations; }
    public function addReservation(Reservation $reservation): self { if (!$this->reservations->contains($reservation)) { $this->reservations->add($reservation); $reservation->setMachine($this); } return $this; }
    public function removeReservation(Reservation $reservation): self { if ($this->reservations->removeElement($reservation)) { if ($reservation->getMachine() === $this) { $reservation->setMachine(null); } } return $this; }

    public function getLogsUtilisation(): Collection { return $this->logsUtilisation; }
    public function addLogsUtilisation(LogUtilisation $logsUtilisation): self { if (!$this->logsUtilisation->contains($logsUtilisation)) { $this->logsUtilisation->add($logsUtilisation); $logsUtilisation->setMachine($this); } return $this; }
    public function removeLogsUtilisation(LogUtilisation $logsUtilisation): self { if ($this->logsUtilisation->removeElement($logsUtilisation)) { if ($logsUtilisation->getMachine() === $this) { $logsUtilisation->setMachine(null); } } return $this; }
}