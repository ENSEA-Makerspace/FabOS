<?php
// src/Entity/Progression.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'PROGRESSION')]
class Progression
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: Utilisateur::class, inversedBy: 'progressions')]
    #[ORM\JoinColumn(name: 'userId', referencedColumnName: 'id')]
    private Utilisateur $user;

    #[ORM\ManyToOne(targetEntity: Formation::class, inversedBy: 'progressions')]
    #[ORM\JoinColumn(name: 'formationId', referencedColumnName: 'id')]
    private Formation $formation;

    #[ORM\Column(type: 'integer', options: ['default' => 0])]
    private int $score = 0;

    #[ORM\Column(type: 'boolean', options: ['default' => false])]
    private bool $completed = false;

    #[ORM\Column(type: 'datetime', options: ['default' => 'CURRENT_TIMESTAMP'])]
    private \DateTimeInterface $dateDebut;

    #[ORM\Column(type: 'datetime', nullable: true)]
    private ?\DateTimeInterface $dateEnd = null;

    public function __construct()
    {
        $this->dateDebut = new \DateTime();
    }
    public function setDateEnd(?\DateTimeInterface $dateEnd): self
    {
        if ($dateEnd && $this->dateDebut && $dateEnd <= $this->dateDebut) {
            throw new \InvalidArgumentException('dateEnd doit être postérieure à dateDebut');
        }
        $this->dateEnd = $dateEnd;
        return $this;
    }
    // Getters & Setters
    public function getId(): ?int { return $this->id; }
    public function getUser(): Utilisateur { return $this->user; }
    public function setUser(Utilisateur $user): self { $this->user = $user; return $this; }
    public function getFormation(): Formation { return $this->formation; }
    public function setFormation(Formation $formation): self { $this->formation = $formation; return $this; }
    public function getScore(): int { return $this->score; }
    public function setScore(int $score): self { $this->score = $score; return $this; }
    public function isCompleted(): bool { return $this->completed; }
    public function setCompleted(bool $completed): self { $this->completed = $completed; return $this; }
    public function getDateDebut(): \DateTimeInterface { return $this->dateDebut; }
    public function setDateDebut(\DateTimeInterface $dateDebut): self { $this->dateDebut = $dateDebut; return $this; }
    public function getDateEnd(): ?\DateTimeInterface { return $this->dateEnd; }
}