<?php
// src/Entity/Reservation.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'RESERVATION')]
class Reservation
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: Utilisateur::class, inversedBy: 'reservations')]
    #[ORM\JoinColumn(name: 'userId', referencedColumnName: 'id')]
    private Utilisateur $user;

    #[ORM\ManyToOne(targetEntity: Machine::class, inversedBy: 'reservations')]
    #[ORM\JoinColumn(name: 'machineId', referencedColumnName: 'id')]
    private Machine $machine;

    #[ORM\Column(type: 'datetime')]
    private \DateTimeInterface $dateDebut;

    #[ORM\Column(type: 'datetime')]
    private \DateTimeInterface $dateFin;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $motif = null;

    #[ORM\Column(type: 'datetime', options: ['default' => 'CURRENT_TIMESTAMP'])]
    private \DateTimeInterface $created;

    public function __construct()
    {
        $this->created = new \DateTime();
    }
    public function setDateFin(\DateTimeInterface $dateFin): self
    {
        if ($this->dateDebut && $dateFin <= $this->dateDebut) {
            throw new \InvalidArgumentException('dateFin doit être postérieure à dateDebut');
        }
        $this->dateFin = $dateFin;
        return $this;
    }

    // Getters & Setters
    public function getId(): ?int { return $this->id; }
    public function getUser(): Utilisateur { return $this->user; }
    public function setUser(Utilisateur $user): self { $this->user = $user; return $this; }
    public function getMachine(): Machine { return $this->machine; }
    public function setMachine(Machine $machine): self { $this->machine = $machine; return $this; }
    public function getDateDebut(): \DateTimeInterface { return $this->dateDebut; }
    public function setDateDebut(\DateTimeInterface $dateDebut): self { $this->dateDebut = $dateDebut; return $this; }
    public function getDateFin(): \DateTimeInterface { return $this->dateFin; }
    public function getMotif(): ?string { return $this->motif; }
    public function setMotif(?string $motif): self { $this->motif = $motif; return $this; }
    public function getCreated(): \DateTimeInterface { return $this->created; }
    public function setCreated(\DateTimeInterface $created): self { $this->created = $created; return $this; }
}