<?php
// src/Entity/Utilisateur.php
namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'UTILISATEUR')]
class Utilisateur
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\Column(type: 'string', length: 255, unique: true)]
    private string $email;

    #[ORM\Column(type: 'string', length: 255, unique: true)]
    private string $username;

    #[ORM\Column(type: 'string', length: 255)]
    private string $password;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private ?string $firstName = null;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private ?string $lastName = null;

    #[ORM\Column(type: 'string', length: 255, unique: true, nullable: true)]
    private ?string $numeroId = null;

    #[ORM\Column(type: 'string', length: 50, options: ['default' => 'actif'])]
    private string $statut = 'actif';

    #[ORM\Column(type: 'string', length: 255, unique: true, nullable: true)]
    private ?string $identifiantRfid = null;

    #[ORM\Column(type: 'integer', options: ['default' => 0])]
    private int $tempsPresenceTotal = 0;

    #[ORM\Column(type: 'boolean', options: ['default' => false])]
    private bool $isVerified = false;

    #[ORM\Column(type: 'datetime', options: ['default' => 'CURRENT_TIMESTAMP'])]
    private \DateTimeInterface $createdAt;

    #[ORM\Column(type: 'datetime', nullable: true)]
    private ?\DateTimeInterface $derniereConnexion = null;

    #[ORM\Column(type: 'boolean', options: ['default' => true])]
    private bool $notificationEmail = true;

    #[ORM\Column(type: 'boolean', options: ['default' => false])]
    private bool $notificationPush = false;

    #[ORM\Column(type: 'boolean', options: ['default' => true])]
    private bool $rappelReservation = true;

    #[ORM\Column(type: 'string', length: 50, options: ['default' => 'clair'])]
    private string $theme = 'clair';

    #[ORM\Column(type: 'string', length: 10, options: ['default' => 'fr'])]
    private string $langue = 'fr';

    #[ORM\ManyToMany(targetEntity: Role::class, inversedBy: 'utilisateurs')]
    #[ORM\JoinTable(name: 'UTILISATEUR_ROLE')]
    #[ORM\JoinColumn(name: 'utilisateurId', referencedColumnName: 'id')]
    #[ORM\InverseJoinColumn(name: 'roleId', referencedColumnName: 'id')]
    private Collection $roles;

    #[ORM\OneToMany(mappedBy: 'utilisateur', targetEntity: UtilisateurFormation::class)]
    private Collection $utilisateurFormations;

    #[ORM\OneToMany(mappedBy: 'utilisateur', targetEntity: UtilisateurBadge::class)]
    private Collection $utilisateurBadges;

    #[ORM\OneToMany(mappedBy: 'user', targetEntity: Reservation::class)]
    private Collection $reservations;

    #[ORM\OneToMany(mappedBy: 'user', targetEntity: LogUtilisation::class)]
    private Collection $logsUtilisation;

    #[ORM\OneToMany(mappedBy: 'user', targetEntity: Progression::class)]
    private Collection $progressions;

    public function __construct()
    {
        $this->roles = new ArrayCollection();
        $this->utilisateurFormations = new ArrayCollection();
        $this->utilisateurBadges = new ArrayCollection();
        $this->reservations = new ArrayCollection();
        $this->logsUtilisation = new ArrayCollection();
        $this->progressions = new ArrayCollection();
        $this->createdAt = new \DateTime();
    }

    // Getters & Setters
    public function getId(): ?int { return $this->id; }
    public function getEmail(): string { return $this->email; }
    public function setEmail(string $email): self { $this->email = $email; return $this; }
    public function getUsername(): string { return $this->username; }
    public function setUsername(string $username): self { $this->username = $username; return $this; }
    public function getPassword(): string { return $this->password; }
    public function setPassword(string $password): self { $this->password = $password; return $this; }
    public function getFirstName(): ?string { return $this->firstName; }
    public function setFirstName(?string $firstName): self { $this->firstName = $firstName; return $this; }
    public function getLastName(): ?string { return $this->lastName; }
    public function setLastName(?string $lastName): self { $this->lastName = $lastName; return $this; }
    public function getNumeroId(): ?string { return $this->numeroId; }
    public function setNumeroId(?string $numeroId): self { $this->numeroId = $numeroId; return $this; }
    public function getStatut(): string { return $this->statut; }
    public function setStatut(string $statut): self { $this->statut = $statut; return $this; }
    public function getIdentifiantRfid(): ?string { return $this->identifiantRfid; }
    public function setIdentifiantRfid(?string $identifiantRfid): self { $this->identifiantRfid = $identifiantRfid; return $this; }
    public function getTempsPresenceTotal(): int { return $this->tempsPresenceTotal; }
    public function setTempsPresenceTotal(int $tempsPresenceTotal): self { $this->tempsPresenceTotal = $tempsPresenceTotal; return $this; }
    public function isVerified(): bool { return $this->isVerified; }
    public function setIsVerified(bool $isVerified): self { $this->isVerified = $isVerified; return $this; }
    public function getCreatedAt(): \DateTimeInterface { return $this->createdAt; }
    public function setCreatedAt(\DateTimeInterface $createdAt): self { $this->createdAt = $createdAt; return $this; }
    public function getDerniereConnexion(): ?\DateTimeInterface { return $this->derniereConnexion; }
    public function setDerniereConnexion(?\DateTimeInterface $derniereConnexion): self { $this->derniereConnexion = $derniereConnexion; return $this; }
    public function isNotificationEmail(): bool { return $this->notificationEmail; }
    public function setNotificationEmail(bool $notificationEmail): self { $this->notificationEmail = $notificationEmail; return $this; }
    public function isNotificationPush(): bool { return $this->notificationPush; }
    public function setNotificationPush(bool $notificationPush): self { $this->notificationPush = $notificationPush; return $this; }
    public function isRappelReservation(): bool { return $this->rappelReservation; }
    public function setRappelReservation(bool $rappelReservation): self { $this->rappelReservation = $rappelReservation; return $this; }
    public function getTheme(): string { return $this->theme; }
    public function setTheme(string $theme): self { $this->theme = $theme; return $this; }
    public function getLangue(): string { return $this->langue; }
    public function setLangue(string $langue): self { $this->langue = $langue; return $this; }

    public function getRoles(): Collection { return $this->roles; }
    public function addRole(Role $role): self { if (!$this->roles->contains($role)) { $this->roles->add($role); } return $this; }
    public function removeRole(Role $role): self { $this->roles->removeElement($role); return $this; }

    public function getReservations(): Collection { return $this->reservations; }
    public function addReservation(Reservation $reservation): self { if (!$this->reservations->contains($reservation)) { $this->reservations->add($reservation); $reservation->setUser($this); } return $this; }
    public function removeReservation(Reservation $reservation): self { if ($this->reservations->removeElement($reservation)) { if ($reservation->getUser() === $this) { $reservation->setUser(null); } } return $this; }

    public function getLogsUtilisation(): Collection { return $this->logsUtilisation; }
    public function addLogsUtilisation(LogUtilisation $logsUtilisation): self { if (!$this->logsUtilisation->contains($logsUtilisation)) { $this->logsUtilisation->add($logsUtilisation); $logsUtilisation->setUser($this); } return $this; }
    public function removeLogsUtilisation(LogUtilisation $logsUtilisation): self { if ($this->logsUtilisation->removeElement($logsUtilisation)) { if ($logsUtilisation->getUser() === $this) { $logsUtilisation->setUser(null); } } return $this; }

    public function getProgressions(): Collection { return $this->progressions; }
    public function addProgression(Progression $progression): self { if (!$this->progressions->contains($progression)) { $this->progressions->add($progression); $progression->setUser($this); } return $this; }
    public function removeProgression(Progression $progression): self { if ($this->progressions->removeElement($progression)) { if ($progression->getUser() === $this) { $progression->setUser(null); } } return $this; }
}