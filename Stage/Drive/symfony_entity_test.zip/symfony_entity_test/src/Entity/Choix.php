<?php
// src/Entity/Choix.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'CHOIX')]
class Choix
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: Question::class, inversedBy: 'choix')]
    #[ORM\JoinColumn(name: 'questionId', referencedColumnName: 'id')]
    private Question $question;

    #[ORM\Column(type: 'text')]
    private string $texte;

    #[ORM\Column(type: 'boolean')]
    private bool $estCorrect;

    #[ORM\Column(type: 'integer')]
    private int $ordre;

    // Getters & Setters
    public function getId(): ?int { return $this->id; }
    public function getQuestion(): Question { return $this->question; }
    public function setQuestion(Question $question): self { $this->question = $question; return $this; }
    public function getTexte(): string { return $this->texte; }
    public function setTexte(string $texte): self { $this->texte = $texte; return $this; }
    public function isEstCorrect(): bool { return $this->estCorrect; }
    public function setEstCorrect(bool $estCorrect): self { $this->estCorrect = $estCorrect; return $this; }
    public function getOrdre(): int { return $this->ordre; }
    public function setOrdre(int $ordre): self { $this->ordre = $ordre; return $this; }
}