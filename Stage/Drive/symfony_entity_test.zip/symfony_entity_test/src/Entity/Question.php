<?php
// src/Entity/Question.php
namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'QUESTION')]
class Question
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: Quiz::class, inversedBy: 'questions')]
    #[ORM\JoinColumn(name: 'quizId', referencedColumnName: 'id')]
    private Quiz $quiz;

    #[ORM\Column(type: 'text')]
    private string $texte;

    #[ORM\Column(type: 'string', length: 50)]
    private string $type;

    #[ORM\Column(type: 'integer')]
    private int $ordre;

    #[ORM\OneToMany(mappedBy: 'question', targetEntity: Choix::class)]
    private Collection $choix;

    public function __construct()
    {
        $this->choix = new ArrayCollection();
    }

    // Getters & Setters
    public function getId(): ?int { return $this->id; }
    public function getQuiz(): Quiz { return $this->quiz; }
    public function setQuiz(Quiz $quiz): self { $this->quiz = $quiz; return $this; }
    public function getTexte(): string { return $this->texte; }
    public function setTexte(string $texte): self { $this->texte = $texte; return $this; }
    public function getType(): string { return $this->type; }
    public function setType(string $type): self { $this->type = $type; return $this; }
    public function getOrdre(): int { return $this->ordre; }
    public function setOrdre(int $ordre): self { $this->ordre = $ordre; return $this; }

    public function getChoix(): Collection { return $this->choix; }
    public function addChoix(Choix $choix): self { if (!$this->choix->contains($choix)) { $this->choix->add($choix); $choix->setQuestion($this); } return $this; }
    public function removeChoix(Choix $choix): self { if ($this->choix->removeElement($choix)) { if ($choix->getQuestion() === $this) { $choix->setQuestion(null); } } return $this; }
}