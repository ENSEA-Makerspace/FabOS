<?php
// src/Entity/Horaires.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'HORAIRES')]
class Horaires
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\Column(type: 'string', length: 20)]
    private string $jour;

    #[ORM\Column(type: 'time')]
    private \DateTimeInterface $heureOuverture;

    #[ORM\Column(type: 'time')]
    private \DateTimeInterface $heureFermeture;

    // Getters & Setters
    public function getId(): ?int { return $this->id; }
    public function getJour(): string { return $this->jour; }
    public function setJour(string $jour): self { $this->jour = $jour; return $this; }
    public function getHeureOuverture(): \DateTimeInterface { return $this->heureOuverture; }
    public function setHeureOuverture(\DateTimeInterface $heureOuverture): self { $this->heureOuverture = $heureOuverture; return $this; }
    public function getHeureFermeture(): \DateTimeInterface { return $this->heureFermeture; }
    public function setHeureFermeture(\DateTimeInterface $heureFermeture): self { $this->heureFermeture = $heureFermeture; return $this; }
}