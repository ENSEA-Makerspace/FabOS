<?php
// src/Entity/Role.php
namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
class Role
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\Column(type: 'string', length: 50, unique: true)]
    private string $nom;

    #[ORM\ManyToMany(targetEntity: Utilisateur::class, mappedBy: 'roles')]
    private Collection $utilisateurs;

    public function __construct()
    {
        $this->utilisateurs = new ArrayCollection();
    }

    // Getters & Setters
    public function getId(): ?int { return $this->id; }
    public function getNom(): string { return $this->nom; }
    public function setNom(string $nom): self { $this->nom = $nom; return $this; }

    public function getUtilisateurs(): Collection { return $this->utilisateurs; }
    public function addUtilisateur(Utilisateur $utilisateur): self { if (!$this->utilisateurs->contains($utilisateur)) { $this->utilisateurs->add($utilisateur); $utilisateur->addRole($this); } return $this; }
    public function removeUtilisateur(Utilisateur $utilisateur): self { if ($this->utilisateurs->removeElement($utilisateur)) { $utilisateur->removeRole($this); } return $this; }
}