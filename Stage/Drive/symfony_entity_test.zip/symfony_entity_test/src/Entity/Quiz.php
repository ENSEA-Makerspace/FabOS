<?php
// src/Entity/Quiz.php
namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'QUIZ')]
class Quiz
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: Formation::class, inversedBy: 'quizs')]
    #[ORM\JoinColumn(name: 'formationId', referencedColumnName: 'id')]
    private Formation $formation;

    #[ORM\ManyToOne(targetEntity: Section::class, inversedBy: 'quizs')]
    #[ORM\JoinColumn(name: 'sectionId', referencedColumnName: 'id')]
    private ?Section $section = null;

    #[ORM\Column(type: 'integer', options: ['default' => 0])]
    private int $noteMinimale = 0;

    #[ORM\OneToMany(mappedBy: 'quiz', targetEntity: Question::class)]
    private Collection $questions;

    public function __construct()
    {
        $this->questions = new ArrayCollection();
    }

    // Getters & Setters
    public function getId(): ?int { return $this->id; }
    public function getFormation(): Formation { return $this->formation; }
    public function setFormation(Formation $formation): self { $this->formation = $formation; return $this; }
    public function getSection(): ?Section { return $this->section; }
    public function setSection(?Section $section): self { $this->section = $section; return $this; }
    public function getNoteMinimale(): int { return $this->noteMinimale; }
    public function setNoteMinimale(int $noteMinimale): self { $this->noteMinimale = $noteMinimale; return $this; }

    public function getQuestions(): Collection { return $this->questions; }
    public function addQuestion(Question $question): self { if (!$this->questions->contains($question)) { $this->questions->add($question); $question->setQuiz($this); } return $this; }
    public function removeQuestion(Question $question): self { if ($this->questions->removeElement($question)) { if ($question->getQuiz() === $this) { $question->setQuiz(null); } } return $this; }
}