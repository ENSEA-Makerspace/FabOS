<?php
// src/Entity/Formation.php
namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
class Formation
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\ManyToOne(targetEntity: Badge::class, inversedBy: 'formations')]
    #[ORM\JoinColumn(name: 'badgeId', referencedColumnName: 'id')]
    private ?Badge $badge = null;

    #[ORM\Column(type: 'string', length: 255)]
    private string $titre;

    #[ORM\Column(type: 'integer', options: ['default' => 0])]
    private int $durée = 0;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $caracteristiques = null;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private ?string $formateur = null;

    #[ORM\Column(type: 'integer', options: ['default' => 0])]
    private int $placeTotale = 0;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $description = null;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $programme = null;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $prerequis = null;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $materialFourni = null;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private ?string $image = null;

    #[ORM\OneToMany(mappedBy: 'formation', targetEntity: UtilisateurFormation::class)]
    private Collection $utilisateurFormations;

    #[ORM\OneToMany(mappedBy: 'formation', targetEntity: Progression::class)]
    private Collection $progressions;

    #[ORM\OneToMany(mappedBy: 'formation', targetEntity: Section::class)]
    private Collection $sections;

    #[ORM\OneToMany(mappedBy: 'formation', targetEntity: Quiz::class)]
    private Collection $quizs;

    public function __construct()
    {
        $this->utilisateurFormations = new ArrayCollection();
        $this->progressions = new ArrayCollection();
        $this->sections = new ArrayCollection();
        $this->quizs = new ArrayCollection();
    }

    // Getters & Setters
    public function getId(): ?int { return $this->id; }
    public function getBadge(): ?Badge { return $this->badge; }
    public function setBadge(?Badge $badge): self { $this->badge = $badge; return $this; }
    public function getTitre(): string { return $this->titre; }
    public function setTitre(string $titre): self { $this->titre = $titre; return $this; }
    public function getDurée(): int { return $this->durée; }
    public function setDurée(int $durée): self { $this->durée = $durée; return $this; }
    public function getCaracteristiques(): ?string { return $this->caracteristiques; }
    public function setCaracteristiques(?string $caracteristiques): self { $this->caracteristiques = $caracteristiques; return $this; }
    public function getFormateur(): ?string { return $this->formateur; }
    public function setFormateur(?string $formateur): self { $this->formateur = $formateur; return $this; }
    public function getPlaceTotale(): int { return $this->placeTotale; }
    public function setPlaceTotale(int $placeTotale): self { $this->placeTotale = $placeTotale; return $this; }
    public function getDescription(): ?string { return $this->description; }
    public function setDescription(?string $description): self { $this->description = $description; return $this; }
    public function getProgramme(): ?string { return $this->programme; }
    public function setProgramme(?string $programme): self { $this->programme = $programme; return $this; }
    public function getPrerequis(): ?string { return $this->prerequis; }
    public function setPrerequis(?string $prerequis): self { $this->prerequis = $prerequis; return $this; }
    public function getMaterialFourni(): ?string { return $this->materialFourni; }
    public function setMaterialFourni(?string $materialFourni): self { $this->materialFourni = $materialFourni; return $this; }
    public function getImage(): ?string { return $this->image; }
    public function setImage(?string $image): self { $this->image = $image; return $this; }

    public function getProgressions(): Collection { return $this->progressions; }
    public function addProgression(Progression $progression): self { if (!$this->progressions->contains($progression)) { $this->progressions->add($progression); $progression->setFormation($this); } return $this; }
    public function removeProgression(Progression $progression): self { if ($this->progressions->removeElement($progression)) { if ($progression->getFormation() === $this) { $progression->setFormation(null); } } return $this; }

    public function getSections(): Collection { return $this->sections; }
    public function addSection(Section $section): self { if (!$this->sections->contains($section)) { $this->sections->add($section); $section->setFormation($this); } return $this; }
    public function removeSection(Section $section): self { if ($this->sections->removeElement($section)) { if ($section->getFormation() === $this) { $section->setFormation(null); } } return $this; }

    public function getQuizs(): Collection { return $this->quizs; }
    public function addQuiz(Quiz $quiz): self { if (!$this->quizs->contains($quiz)) { $this->quizs->add($quiz); $quiz->setFormation($this); } return $this; }
    public function removeQuiz(Quiz $quiz): self { if ($this->quizs->removeElement($quiz)) { if ($quiz->getFormation() === $this) { $quiz->setFormation(null); } } return $this; }
}