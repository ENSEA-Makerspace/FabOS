<?php
// src/Entity/UtilisateurBadge.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'UTILISATEUR_BADGE')]
class UtilisateurBadge
{
    #[ORM\Id]
    #[ORM\ManyToOne(targetEntity: Utilisateur::class, inversedBy: 'utilisateurBadges')]
    #[ORM\JoinColumn(name: 'utilisateurId', referencedColumnName: 'id')]
    private Utilisateur $utilisateur;

    #[ORM\Id]
    #[ORM\ManyToOne(targetEntity: Badge::class, inversedBy: 'utilisateurBadges')]
    #[ORM\JoinColumn(name: 'badgeId', referencedColumnName: 'id')]
    private Badge $badge;

    #[ORM\Column(type: 'datetime', options: ['default' => 'CURRENT_TIMESTAMP'])]
    private \DateTimeInterface $dateObtention;

    public function __construct()
    {
        $this->dateObtention = new \DateTime();
    }

    // Getters & Setters
    public function getUtilisateur(): Utilisateur { return $this->utilisateur; }
    public function setUtilisateur(Utilisateur $utilisateur): self { $this->utilisateur = $utilisateur; return $this; }
    public function getBadge(): Badge { return $this->badge; }
    public function setBadge(Badge $badge): self { $this->badge = $badge; return $this; }
    public function getDateObtention(): \DateTimeInterface { return $this->dateObtention; }
    public function setDateObtention(\DateTimeInterface $dateObtention): self { $this->dateObtention = $dateObtention; return $this; }
}