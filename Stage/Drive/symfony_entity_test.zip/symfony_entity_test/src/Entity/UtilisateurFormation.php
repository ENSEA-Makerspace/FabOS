<?php
// src/Entity/UtilisateurFormation.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'UTILISATEUR_FORMATION')]
class UtilisateurFormation
{
    #[ORM\Id]
    #[ORM\ManyToOne(targetEntity: Utilisateur::class, inversedBy: 'utilisateurFormations')]
    #[ORM\JoinColumn(name: 'utilisateurId', referencedColumnName: 'id')]
    private Utilisateur $utilisateur;

    #[ORM\Id]
    #[ORM\ManyToOne(targetEntity: Formation::class, inversedBy: 'utilisateurFormations')]
    #[ORM\JoinColumn(name: 'formationId', referencedColumnName: 'id')]
    private Formation $formation;

    #[ORM\Column(type: 'integer', options: ['default' => 0])]
    private int $placePrise = 0;

    #[ORM\Column(type: 'datetime', options: ['default' => 'CURRENT_TIMESTAMP'])]
    private \DateTimeInterface $dateInscription;

    public function __construct()
    {
        $this->dateInscription = new \DateTime();
    }

    // Getters & Setters
    public function getUtilisateur(): Utilisateur { return $this->utilisateur; }
    public function setUtilisateur(Utilisateur $utilisateur): self { $this->utilisateur = $utilisateur; return $this; }
    public function getFormation(): Formation { return $this->formation; }
    public function setFormation(Formation $formation): self { $this->formation = $formation; return $this; }
    public function getPlacePrise(): int { return $this->placePrise; }
    public function setPlacePrise(int $placePrise): self { $this->placePrise = $placePrise; return $this; }
    public function getDateInscription(): \DateTimeInterface { return $this->dateInscription; }
    public function setDateInscription(\DateTimeInterface $dateInscription): self { $this->dateInscription = $dateInscription; return $this; }
}