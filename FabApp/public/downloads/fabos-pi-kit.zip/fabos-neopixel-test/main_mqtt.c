#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <ctype.h>

#include <mosquitto.h>
#include "rpi_ws281x/ws2811.h"

#define DEFAULT_MQTT_HOST "127.0.0.1"
#define DEFAULT_MQTT_PORT 1883
#define MQTT_KEEPALIVE 60
#define DEFAULT_READER_TOKEN "reader-printer-01"
#define MQTT_RESULT_TOPIC_PREFIX "fabos/access/result/"

#define LED_COUNT      10
#define LED_GPIO       18
#define LED_FREQ_HZ    800000
#define LED_DMA        10
#define LED_BRIGHTNESS 80
#define LED_CHANNEL    0

static volatile int running = 1;
static char mqtt_topic[160];

static ws2811_t ledstring =
{
    .freq = LED_FREQ_HZ,
    .dmanum = LED_DMA,
    .channel =
    {
        [0] =
        {
            .gpionum = LED_GPIO,
            .invert = 0,
            .count = LED_COUNT,
            .strip_type = WS2811_STRIP_GRB,
            .brightness = LED_BRIGHTNESS,
        },
        [1] =
        {
            .gpionum = 0,
            .invert = 0,
            .count = 0,
            .brightness = 0,
        },
    },
};

static void stop_handler(int signum)
{
    (void)signum;
    running = 0;
}

static const char *get_env_or_default(const char *name, const char *fallback)
{
    const char *value = getenv(name);

    if (value == NULL || value[0] == '\0')
    {
        return fallback;
    }

    return value;
}

static int get_mqtt_port(void)
{
    const char *value = getenv("MQTT_PORT");

    if (value == NULL || value[0] == '\0')
    {
        return DEFAULT_MQTT_PORT;
    }

    int port = atoi(value);

    return port > 0 ? port : DEFAULT_MQTT_PORT;
}

static void build_mqtt_topic(void)
{
    const char *reader_token = get_env_or_default("FABOS_READER_TOKEN", DEFAULT_READER_TOKEN);

    snprintf(mqtt_topic, sizeof(mqtt_topic), "%s%s", MQTT_RESULT_TOPIC_PREFIX, reader_token);
}

static ws2811_led_t make_color(uint8_t red, uint8_t green, uint8_t blue)
{
    return ((ws2811_led_t)red << 16) |
           ((ws2811_led_t)green << 8) |
           blue;
}

static void leds_fill(uint8_t red, uint8_t green, uint8_t blue)
{
    ws2811_led_t color = make_color(red, green, blue);

    for (int i = 0; i < LED_COUNT; i++)
    {
        ledstring.channel[LED_CHANNEL].leds[i] = color;
    }

    ws2811_render(&ledstring);
}

static void leds_clear(void)
{
    leds_fill(0, 0, 0);
}

static void leds_sequence(uint8_t red, uint8_t green, uint8_t blue)
{
    ws2811_led_t color = make_color(red, green, blue);

    /*
     * Étape 1 :
     * Les LEDs s'allument une par une.
     */
    leds_clear();

    for (int i = 0; i < LED_COUNT && running; i++)
    {
        ledstring.channel[LED_CHANNEL].leds[i] = color;
        ws2811_render(&ledstring);
        usleep(120000);
    }

    /*
     * Étape 2 :
     * Tout s'éteint pendant 1 seconde.
     */
    leds_clear();
    sleep(1);

    /*
     * Étape 3 :
     * Toutes les LEDs clignotent 2 fois.
     */
    for (int i = 0; i < 2 && running; i++)
    {
        leds_fill(red, green, blue);
        usleep(250000);

        leds_clear();
        usleep(250000);
    }

    /*
     * Étape 4 :
     * On laisse la couleur affichée.
     */
    leds_fill(red, green, blue);
}

/*
 * Petit extracteur JSON simple.
 *
 * Il cherche une valeur texte comme :
 * "color":"green"
 * ou
 * "message":"Bienvenue Yanis"
 *
 * Ce n'est pas un parseur JSON complet, mais c'est suffisant
 * pour nos tests MQTT actuels.
 */
static int extract_json_string_value(const char *json, const char *key, char *out, size_t out_size)
{
    char pattern[64];

    snprintf(pattern, sizeof(pattern), "\"%s\"", key);

    const char *pos = strstr(json, pattern);

    if (!pos)
    {
        return 0;
    }

    pos += strlen(pattern);

    while (*pos && isspace((unsigned char)*pos))
    {
        pos++;
    }

    if (*pos != ':')
    {
        return 0;
    }

    pos++;

    while (*pos && isspace((unsigned char)*pos))
    {
        pos++;
    }

    if (*pos != '"')
    {
        return 0;
    }

    pos++;

    size_t i = 0;

    while (*pos && *pos != '"' && i < out_size - 1)
    {
        out[i++] = *pos++;
    }

    out[i] = '\0';

    return i > 0;
}

static void apply_color_from_json(const char *payload)
{
    char color[32];
    char status[64];
    char message[128];
    char uid[64];

    color[0] = '\0';
    status[0] = '\0';
    message[0] = '\0';
    uid[0] = '\0';

    extract_json_string_value(payload, "color", color, sizeof(color));
    extract_json_string_value(payload, "status", status, sizeof(status));
    extract_json_string_value(payload, "message", message, sizeof(message));
    extract_json_string_value(payload, "uid", uid, sizeof(uid));

    if (color[0] == '\0')
    {
        if (strstr(payload, "\"authorized\":true") != NULL)
        {
            strncpy(color, "green", sizeof(color) - 1);
            color[sizeof(color) - 1] = '\0';
        }
        else if (strcmp(status, "missing_badge") == 0)
        {
            strncpy(color, "orange", sizeof(color) - 1);
            color[sizeof(color) - 1] = '\0';
        }
        else if (strcmp(status, "server_error") == 0 || strcmp(status, "invalid_payload") == 0)
        {
            strncpy(color, "purple", sizeof(color) - 1);
            color[sizeof(color) - 1] = '\0';
        }
        else if (strcmp(status, "unknown_rfid") == 0 || strcmp(status, "unknown_machine") == 0 || strcmp(status, "refused") == 0)
        {
            strncpy(color, "red", sizeof(color) - 1);
            color[sizeof(color) - 1] = '\0';
        }
    }

    printf("\n=== Résultat MQTT reçu ===\n");
    printf("Payload : %s\n", payload);

    if (uid[0] != '\0')
    {
        printf("UID     : %s\n", uid);
    }

    if (status[0] != '\0')
    {
        printf("Status  : %s\n", status);
    }

    if (message[0] != '\0')
    {
        printf("Message : %s\n", message);
    }

    printf("Couleur demandée : %s\n", color);

    if (strcmp(color, "green") == 0)
    {
        printf("Action NeoPixels : séquence VERTE, accès autorisé\n");
        leds_sequence(0, 40, 0);
    }
    else if (strcmp(color, "red") == 0)
    {
        printf("Action NeoPixels : séquence ROUGE, badge inconnu/refusé\n");
        leds_sequence(40, 0, 0);
    }
    else if (strcmp(color, "orange") == 0)
    {
        printf("Action NeoPixels : séquence ORANGE, badge requis manquant\n");
        leds_sequence(40, 12, 0);
    }
    else if (strcmp(color, "blue") == 0)
    {
        printf("Action NeoPixels : séquence BLEUE\n");
        leds_sequence(0, 0, 40);
    }
    else if (strcmp(color, "purple") == 0)
    {
        printf("Action NeoPixels : séquence VIOLETTE, erreur système\n");
        leds_sequence(25, 0, 35);
    }
    else if (strcmp(color, "white") == 0)
    {
        printf("Action NeoPixels : séquence BLANCHE\n");
        leds_sequence(30, 30, 30);
    }
    else if (strcmp(color, "off") == 0)
    {
        printf("Action NeoPixels : OFF\n");
        leds_clear();
    }
    else
    {
        printf("Couleur inconnue, séquence VIOLETTE par défaut\n");
        leds_sequence(25, 0, 35);
    }

    printf("===========================\n");
}

static void on_connect(struct mosquitto *mosq, void *userdata, int rc)
{
    (void)userdata;

    if (rc == 0)
    {
        printf("Connecté au broker MQTT\n");
        printf("Abonnement au topic : %s\n", mqtt_topic);

        int result = mosquitto_subscribe(mosq, NULL, mqtt_topic, 1);

        if (result != MOSQ_ERR_SUCCESS)
        {
            printf("Erreur abonnement MQTT : %s\n", mosquitto_strerror(result));
        }
    }
    else
    {
        printf("Erreur connexion MQTT, code : %d\n", rc);
    }
}

static void on_message(struct mosquitto *mosq, void *userdata, const struct mosquitto_message *message)
{
    (void)mosq;
    (void)userdata;

    if (message->payloadlen <= 0)
    {
        return;
    }

    char payload[1024];

    int len = message->payloadlen;

    if (len >= (int)sizeof(payload))
    {
        len = sizeof(payload) - 1;
    }

    memcpy(payload, message->payload, len);
    payload[len] = '\0';

    apply_color_from_json(payload);
}

int main(void)
{
    struct mosquitto *mosq;

    signal(SIGINT, stop_handler);
    signal(SIGTERM, stop_handler);
    build_mqtt_topic();

    ws2811_return_t led_result = ws2811_init(&ledstring);

    if (led_result != WS2811_SUCCESS)
    {
        fprintf(stderr, "Erreur ws2811_init : %s\n", ws2811_get_return_t_str(led_result));
        return 1;
    }

    printf("NeoPixels initialisés sur GPIO%d\n", LED_GPIO);

    /*
     * Couleur d'attente au démarrage : bleu faible.
     */
    leds_fill(0, 0, 25);

    mosquitto_lib_init();

    mosq = mosquitto_new("fabos-neopixel-mqtt", true, NULL);

    if (!mosq)
    {
        printf("Erreur : impossible de créer le client MQTT\n");

        leds_clear();
        ws2811_fini(&ledstring);
        mosquitto_lib_cleanup();

        return 1;
    }

    mosquitto_connect_callback_set(mosq, on_connect);
    mosquitto_message_callback_set(mosq, on_message);

    printf("Connexion au broker MQTT %s:%d...\n", get_env_or_default("MQTT_HOST", DEFAULT_MQTT_HOST), get_mqtt_port());
    printf("Topic NeoPixel : %s\n", mqtt_topic);

    int mqtt_result = mosquitto_connect(mosq, get_env_or_default("MQTT_HOST", DEFAULT_MQTT_HOST), get_mqtt_port(), MQTT_KEEPALIVE);

    if (mqtt_result != MOSQ_ERR_SUCCESS)
    {
        printf("Erreur mosquitto_connect : %s\n", mosquitto_strerror(mqtt_result));

        mosquitto_destroy(mosq);
        leds_clear();
        ws2811_fini(&ledstring);
        mosquitto_lib_cleanup();

        return 1;
    }

    printf("En attente des messages MQTT...\n");

    while (running)
    {
        mosquitto_loop(mosq, 100, 1);
    }

    printf("\nArrêt du programme...\n");

    mosquitto_disconnect(mosq);
    mosquitto_destroy(mosq);
    mosquitto_lib_cleanup();

    leds_clear();
    ws2811_fini(&ledstring);

    return 0;
}
