#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <signal.h>

#include "rpi_ws281x/ws2811.h"

#define LED_COUNT      10
#define LED_GPIO       18
#define LED_FREQ_HZ    800000
#define LED_DMA        10
#define LED_BRIGHTNESS 80
#define LED_CHANNEL    0

static volatile int running = 1;

static ws2811_t ledstring =
{
    .freq = LED_FREQ_HZ,
    .dmanum = LED_DMA,
    .channel =
    {
        [0] =
        {
            .gpionum = LED_GPIO,
            .invert = 0,
            .count = LED_COUNT,
            .strip_type = WS2811_STRIP_GRB,
            .brightness = LED_BRIGHTNESS,
        },
        [1] =
        {
            .gpionum = 0,
            .invert = 0,
            .count = 0,
            .brightness = 0,
        },
    },
};

static void stop_handler(int signum)
{
    (void)signum;
    running = 0;
}

static ws2811_led_t color(uint8_t red, uint8_t green, uint8_t blue)
{
    return ((ws2811_led_t)red << 16) |
           ((ws2811_led_t)green << 8) |
           blue;
}

static void fill(uint8_t red, uint8_t green, uint8_t blue)
{
    ws2811_led_t c = color(red, green, blue);

    for (int i = 0; i < LED_COUNT; i++)
    {
        ledstring.channel[LED_CHANNEL].leds[i] = c;
    }

    ws2811_render(&ledstring);
}

static void clear_leds(void)
{
    fill(0, 0, 0);
}

static void chase(uint8_t red, uint8_t green, uint8_t blue)
{
    for (int i = 0; i < LED_COUNT && running; i++)
    {
        clear_leds();

        ledstring.channel[LED_CHANNEL].leds[i] = color(red, green, blue);
        ws2811_render(&ledstring);

        usleep(150000);
    }
}

int main(void)
{
    ws2811_return_t ret;

    signal(SIGINT, stop_handler);
    signal(SIGTERM, stop_handler);

    ret = ws2811_init(&ledstring);

    if (ret != WS2811_SUCCESS)
    {
        fprintf(stderr, "Erreur ws2811_init: %s\n", ws2811_get_return_t_str(ret));
        return 1;
    }

    printf("FABOS NeoPixel test Raspberry Pi\n");
    printf("GPIO utilisé : GPIO%d / pin physique 12\n", LED_GPIO);
    printf("LED count : %d\n", LED_COUNT);

    while (running)
    {
        fill(30, 0, 0);   // rouge
        sleep(1);

        fill(0, 30, 0);   // vert
        sleep(1);

        fill(0, 0, 30);   // bleu
        sleep(1);

        fill(30, 10, 0);  // orange
        sleep(1);

        chase(0, 30, 0);  // chenillard vert
    }

    clear_leds();
    ws2811_fini(&ledstring);

    return 0;
}
