#!/bin/bash

FABOS_HOME="${FABOS_HOME:-$HOME}"
FABOS_ENV_FILE="$FABOS_HOME/fabos-device.env"

if [ -f "$FABOS_ENV_FILE" ]; then
    set -a
    . "$FABOS_ENV_FILE"
    set +a
fi

export FABOS_READER_TOKEN="${FABOS_READER_TOKEN:-reader-printer-01}"
export FABOS_MACHINE_TOKEN="${FABOS_MACHINE_TOKEN:-printer-01}"
export MQTT_HOST="${MQTT_HOST:-127.0.0.1}"
export MQTT_PORT="${MQTT_PORT:-1883}"
export FABOS_MQTT_HOST="$MQTT_HOST"
export FABOS_MQTT_PORT="$MQTT_PORT"

FABOS_NEOPIXEL_DIR="$FABOS_HOME/fabos-neopixel-test"
FABOS_WORKER_DIR="$FABOS_HOME/fabos-php-worker"
FABOS_RFID_DIR="$FABOS_HOME/fabos-rfid"
FABOS_NEOPIXEL_LOG="$FABOS_HOME/fabos-neopixel.log"
FABOS_WORKER_LOG="$FABOS_HOME/fabos-php-worker.log"
FABOS_RFID_LOG="$FABOS_HOME/fabos-rfid.log"

echo "Démarrage FABOS..."
echo "FABOS home : $FABOS_HOME"
echo "Reader token : $FABOS_READER_TOKEN"
echo "Machine token : $FABOS_MACHINE_TOKEN"
echo "MQTT host : $MQTT_HOST:$MQTT_PORT"

if ! systemctl is-active --quiet mosquitto; then
    echo "Attention : Mosquitto ne semble pas actif. Lance sudo systemctl start mosquitto"
fi

echo "Vérification sudo..."
sudo -v

if [ $? -ne 0 ]; then
    echo "Erreur : sudo nécessaire pour lancer les NeoPixels/RFID."
    exit 1
fi

echo "Arrêt des anciens processus..."
sudo pkill -f fabos-rfid
pkill -f mqtt_worker.php
sudo pkill -f fabos-neopixel-mqtt

sleep 1

echo "Lancement NeoPixels depuis $FABOS_NEOPIXEL_DIR..."
cd "$FABOS_NEOPIXEL_DIR" || exit 1
sudo -E -n ./fabos-neopixel-mqtt > "$FABOS_NEOPIXEL_LOG" 2>&1 &

sleep 1

echo "Lancement PHP worker depuis $FABOS_WORKER_DIR..."
cd "$FABOS_WORKER_DIR" || exit 1
php mqtt_worker.php > "$FABOS_WORKER_LOG" 2>&1 &

sleep 1

echo "Lancement RFID depuis $FABOS_RFID_DIR..."
cd "$FABOS_RFID_DIR" || exit 1
sudo -E -n ./fabos-rfid > "$FABOS_RFID_LOG" 2>&1 &

echo ""
echo "FABOS est lancé."
echo ""
echo "Voir les logs :"
echo "NeoPixels : tail -f $FABOS_NEOPIXEL_LOG"
echo "PHP       : tail -f $FABOS_WORKER_LOG"
echo "RFID      : tail -f $FABOS_RFID_LOG"
