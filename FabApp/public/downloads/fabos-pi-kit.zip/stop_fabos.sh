#!/bin/bash

echo "Arrêt FABOS..."

sudo pkill -f fabos-rfid
pkill -f mqtt_worker.php
sudo pkill -f fabos-neopixel-mqtt

echo "FABOS arrêté."
