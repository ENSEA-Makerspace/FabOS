#include "rc522.h"

#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <linux/spi/spidev.h>

/*
 * RC522 wiring Raspberry Pi 3:
 *
 * RC522 SDA/SS -> GPIO8  / CE0  / physical pin 24
 * RC522 SCK    -> GPIO11 / SCLK / physical pin 23
 * RC522 MOSI   -> GPIO10 / MOSI / physical pin 19
 * RC522 MISO   -> GPIO9  / MISO / physical pin 21
 * RC522 RST    -> GPIO25       / physical pin 22
 * RC522 3.3V   -> 3.3V
 * RC522 GND    -> GND
 *
 * Use SPI device:
 * /dev/spidev0.0
 */

#define PCD_IDLE        0x00
#define PCD_AUTHENT     0x0E
#define PCD_RECEIVE     0x08
#define PCD_TRANSMIT    0x04
#define PCD_TRANSCEIVE  0x0C
#define PCD_RESETPHASE  0x0F
#define PCD_CALCCRC     0x03

#define PICC_REQIDL     0x26
#define PICC_ANTICOLL   0x93

#define CommandReg      0x01
#define ComIEnReg       0x02
#define DivIEnReg       0x03
#define ComIrqReg       0x04
#define DivIrqReg       0x05
#define ErrorReg        0x06
#define Status2Reg      0x08
#define FIFODataReg     0x09
#define FIFOLevelReg    0x0A
#define ControlReg      0x0C
#define BitFramingReg   0x0D
#define ModeReg         0x11
#define TxControlReg    0x14
#define TxAutoReg       0x15
#define TModeReg        0x2A
#define TPrescalerReg   0x2B
#define TReloadRegH     0x2C
#define TReloadRegL     0x2D

static int spi_fd = -1;
static int rc522_rst_gpio = 25;
static uint32_t spi_speed_hz = 1000000; // 1 MHz pour commencer

static int write_text_file(const char *path, const char *value)
{
    int fd = open(path, O_WRONLY);
    if (fd < 0)
    {
        return -1;
    }

    ssize_t result = write(fd, value, strlen(value));
    close(fd);

    return result < 0 ? -1 : 0;
}

static int gpio_export(int gpio)
{
    char buffer[32];

    snprintf(buffer, sizeof(buffer), "%d", gpio);

    if (write_text_file("/sys/class/gpio/export", buffer) < 0)
    {
        // Si le GPIO est déjà exporté, ce n'est pas grave.
    }

    usleep(100000);

    return 0;
}

static int gpio_set_direction(int gpio, const char *direction)
{
    char path[128];

    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/direction", gpio);

    if (write_text_file(path, direction) < 0)
    {
        perror("gpio direction");
        return -1;
    }

    return 0;
}

static int gpio_write_value(int gpio, int value)
{
    char path[128];

    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/value", gpio);

    if (write_text_file(path, value ? "1" : "0") < 0)
    {
        perror("gpio value");
        return -1;
    }

    return 0;
}

int RC522_Linux_Init(const char *spi_device, int rst_gpio)
{
    uint8_t mode = SPI_MODE_0;
    uint8_t bits = 8;

    (void)rst_gpio; // RST n'est pas géré par le code pour l'instant

    spi_fd = open(spi_device, O_RDWR);
    if (spi_fd < 0)
    {
        perror("open spidev");
        return -1;
    }

    if (ioctl(spi_fd, SPI_IOC_WR_MODE, &mode) < 0)
    {
        perror("SPI_IOC_WR_MODE");
        return -1;
    }

    if (ioctl(spi_fd, SPI_IOC_RD_MODE, &mode) < 0)
    {
        perror("SPI_IOC_RD_MODE");
        return -1;
    }

    if (ioctl(spi_fd, SPI_IOC_WR_BITS_PER_WORD, &bits) < 0)
    {
        perror("SPI_IOC_WR_BITS_PER_WORD");
        return -1;
    }

    if (ioctl(spi_fd, SPI_IOC_RD_BITS_PER_WORD, &bits) < 0)
    {
        perror("SPI_IOC_RD_BITS_PER_WORD");
        return -1;
    }

    if (ioctl(spi_fd, SPI_IOC_WR_MAX_SPEED_HZ, &spi_speed_hz) < 0)
    {
        perror("SPI_IOC_WR_MAX_SPEED_HZ");
        return -1;
    }

    if (ioctl(spi_fd, SPI_IOC_RD_MAX_SPEED_HZ, &spi_speed_hz) < 0)
    {
        perror("SPI_IOC_RD_MAX_SPEED_HZ");
        return -1;
    }

    return 0;
}

static void RC522_ResetPin(void)
{
    usleep(50000);
}

static void RC522_WriteRegister(uint8_t addr, uint8_t val)
{
    uint8_t tx[2];
    uint8_t rx[2];

    tx[0] = (addr << 1) & 0x7E;
    tx[1] = val;

    memset(rx, 0, sizeof(rx));

    struct spi_ioc_transfer tr;
    memset(&tr, 0, sizeof(tr));

    tr.tx_buf = (unsigned long)tx;
    tr.rx_buf = (unsigned long)rx;
    tr.len = 2;
    tr.speed_hz = spi_speed_hz;
    tr.bits_per_word = 8;

    if (ioctl(spi_fd, SPI_IOC_MESSAGE(1), &tr) < 1)
    {
        perror("SPI write");
    }
}

static uint8_t RC522_ReadRegister(uint8_t addr)
{
    uint8_t tx[2];
    uint8_t rx[2];

    tx[0] = ((addr << 1) & 0x7E) | 0x80;
    tx[1] = 0x00;

    memset(rx, 0, sizeof(rx));

    struct spi_ioc_transfer tr;
    memset(&tr, 0, sizeof(tr));

    tr.tx_buf = (unsigned long)tx;
    tr.rx_buf = (unsigned long)rx;
    tr.len = 2;
    tr.speed_hz = spi_speed_hz;
    tr.bits_per_word = 8;

    if (ioctl(spi_fd, SPI_IOC_MESSAGE(1), &tr) < 1)
    {
        perror("SPI read");
        return 0;
    }

    return rx[1];
}

static void RC522_SetBitMask(uint8_t reg, uint8_t mask)
{
    uint8_t tmp = RC522_ReadRegister(reg);
    RC522_WriteRegister(reg, tmp | mask);
}

static void RC522_ClearBitMask(uint8_t reg, uint8_t mask)
{
    uint8_t tmp = RC522_ReadRegister(reg);
    RC522_WriteRegister(reg, tmp & (~mask));
}

static void RC522_AntennaOn(void)
{
    uint8_t temp = RC522_ReadRegister(TxControlReg);

    if (!(temp & 0x03))
    {
        RC522_SetBitMask(TxControlReg, 0x03);
    }
}

static void RC522_Reset(void)
{
    RC522_WriteRegister(CommandReg, PCD_RESETPHASE);
}

void RC522_Init(void)
{
    RC522_ResetPin();
    RC522_Reset();

    RC522_WriteRegister(TModeReg, 0x8D);
    RC522_WriteRegister(TPrescalerReg, 0x3E);
    RC522_WriteRegister(TReloadRegL, 30);
    RC522_WriteRegister(TReloadRegH, 0);

    RC522_WriteRegister(TxAutoReg, 0x40);
    RC522_WriteRegister(ModeReg, 0x3D);

    RC522_AntennaOn();
}

static uint8_t RC522_ToCard(uint8_t command,
                            uint8_t *sendData,
                            uint8_t sendLen,
                            uint8_t *backData,
                            uint16_t *backLen)
{
    uint8_t status = MI_ERR;
    uint8_t irqEn = 0x00;
    uint8_t waitIRq = 0x00;
    uint8_t lastBits;
    uint8_t n;
    uint16_t i;

    if (command == PCD_TRANSCEIVE)
    {
        irqEn = 0x77;
        waitIRq = 0x30;
    }

    RC522_WriteRegister(ComIEnReg, irqEn | 0x80);
    RC522_ClearBitMask(ComIrqReg, 0x80);
    RC522_SetBitMask(FIFOLevelReg, 0x80);

    RC522_WriteRegister(CommandReg, PCD_IDLE);

    for (i = 0; i < sendLen; i++)
    {
        RC522_WriteRegister(FIFODataReg, sendData[i]);
    }

    RC522_WriteRegister(CommandReg, command);

    if (command == PCD_TRANSCEIVE)
    {
        RC522_SetBitMask(BitFramingReg, 0x80);
    }

    i = 2000;

    do
    {
        n = RC522_ReadRegister(ComIrqReg);
        i--;
    }
    while ((i != 0) && !(n & 0x01) && !(n & waitIRq));

    RC522_ClearBitMask(BitFramingReg, 0x80);

    if (i != 0)
    {
        if (!(RC522_ReadRegister(ErrorReg) & 0x1B))
        {
            status = MI_OK;

            if (n & irqEn & 0x01)
            {
                status = MI_NOTAGERR;
            }

            if (command == PCD_TRANSCEIVE)
            {
                n = RC522_ReadRegister(FIFOLevelReg);
                lastBits = RC522_ReadRegister(ControlReg) & 0x07;

                if (lastBits)
                {
                    *backLen = (n - 1) * 8 + lastBits;
                }
                else
                {
                    *backLen = n * 8;
                }

                if (n == 0)
                {
                    n = 1;
                }

                if (n > 16)
                {
                    n = 16;
                }

                for (i = 0; i < n; i++)
                {
                    backData[i] = RC522_ReadRegister(FIFODataReg);
                }
            }
        }
        else
        {
            status = MI_ERR;
        }
    }

    return status;
}

uint8_t RC522_Request(uint8_t reqMode, uint8_t *tagType)
{
    uint8_t status;
    uint16_t backBits;

    RC522_WriteRegister(BitFramingReg, 0x07);

    tagType[0] = reqMode;

    status = RC522_ToCard(PCD_TRANSCEIVE, tagType, 1, tagType, &backBits);

    if ((status != MI_OK) || (backBits != 0x10))
    {
        status = MI_ERR;
    }

    return status;
}

uint8_t RC522_Anticoll(uint8_t *serNum)
{
    uint8_t status;
    uint8_t i;
    uint8_t serNumCheck = 0;
    uint16_t unLen;

    RC522_WriteRegister(BitFramingReg, 0x00);

    serNum[0] = PICC_ANTICOLL;
    serNum[1] = 0x20;

    status = RC522_ToCard(PCD_TRANSCEIVE, serNum, 2, serNum, &unLen);

    if (status == MI_OK)
    {
        for (i = 0; i < 4; i++)
        {
            serNumCheck ^= serNum[i];
        }

        if (serNumCheck != serNum[4])
        {
            status = MI_ERR;
        }
    }

    return status;
}

uint8_t RC522_Check(uint8_t *id)
{
    uint8_t status;
    uint8_t tagType[2];

    status = RC522_Request(PICC_REQIDL, tagType);

    if (status == MI_OK)
    {
        status = RC522_Anticoll(id);
    }

    return status;
}

uint8_t RC522_ReadVersion(void)
{
    return RC522_ReadRegister(0x37);
}
