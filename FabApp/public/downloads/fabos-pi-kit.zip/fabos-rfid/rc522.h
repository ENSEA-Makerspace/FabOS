#ifndef RC522_H
#define RC522_H

#include <stdint.h>

#define MI_OK        0
#define MI_NOTAGERR  1
#define MI_ERR       2

int RC522_Linux_Init(const char *spi_device, int rst_gpio);

void RC522_Init(void);
uint8_t RC522_Check(uint8_t *id);
uint8_t RC522_ReadVersion(void);

#endif
