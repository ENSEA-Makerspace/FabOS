#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>

#include "rc522.h"

#define DEFAULT_MQTT_HOST "127.0.0.1"
#define DEFAULT_MQTT_PORT 1883
#define MQTT_TOPIC "fabos/rfid/badge"
#define DEFAULT_READER_TOKEN "reader-printer-01"
#define DEFAULT_MACHINE_TOKEN "printer-01"

#define SAME_BADGE_DELAY_SECONDS 10

uint8_t rc522_version = 0;
uint8_t uid[5];
uint8_t badge_detected = 0;


static const char *get_env_or_default(const char *name, const char *fallback)
{
    const char *value = getenv(name);

    if (value == NULL || value[0] == '\0')
    {
        return fallback;
    }

    return value;
}

static int get_mqtt_port(void)
{
    const char *value = getenv("MQTT_PORT");

    if (value == NULL || value[0] == '\0')
    {
        return DEFAULT_MQTT_PORT;
    }

    int port = atoi(value);

    return port > 0 ? port : DEFAULT_MQTT_PORT;
}

static const char *get_reader_token(void)
{
    return get_env_or_default("FABOS_READER_TOKEN", DEFAULT_READER_TOKEN);
}

static const char *get_machine_token(void)
{
    return get_env_or_default("FABOS_MACHINE_TOKEN", DEFAULT_MACHINE_TOKEN);
}

static uint32_t uid_to_u32(uint8_t *uid)
{
    return ((uint32_t)uid[0] << 24) |
           ((uint32_t)uid[1] << 16) |
           ((uint32_t)uid[2] << 8)  |
           ((uint32_t)uid[3]);
}

static void build_badge_json(uint8_t *uid, char *json, size_t json_size)
{
    time_t now = time(NULL);
    const char *reader_token = get_reader_token();
    const char *machine_token = get_machine_token();

    snprintf(json, json_size,
             "{\"uid\":\"%02X%02X%02X%02X\","
             "\"readerToken\":\"%s\","
             "\"machineToken\":\"%s\","
             "\"source\":\"raspberry-pi\","
             "\"timestamp\":%ld}",
             uid[0], uid[1], uid[2], uid[3],
             reader_token,
             machine_token,
             now);
}

static void publish_badge_json(const char *json)
{
    char command[768];

    snprintf(command, sizeof(command),
             "mosquitto_pub -h %s -p %d -t '%s' -m '%s'",
             get_env_or_default("MQTT_HOST", DEFAULT_MQTT_HOST),
             get_mqtt_port(),
             MQTT_TOPIC,
             json);

    int result = system(command);

    if (result != 0)
    {
        printf("{\"event\":\"mqtt_publish_error\",\"code\":%d}\n", result);
    }
}

static void print_and_publish_badge(uint8_t *uid)
{
    char json[384];

    build_badge_json(uid, json, sizeof(json));

    printf("%s\n", json);
    fflush(stdout);

    publish_badge_json(json);
}

int main(void)
{
    uint32_t last_uid = 0;
    time_t last_publish_time = 0;
    int has_last_uid = 0;

    printf("FABOS RFID - Raspberry Pi + RC522\n");

    if (RC522_Linux_Init("/dev/spidev0.0", 25) != 0)
    {
        printf("{\"event\":\"error\",\"message\":\"linux_rc522_init_failed\"}\n");
        return 1;
    }

    RC522_Init();

    rc522_version = RC522_ReadVersion();

    printf("{\"event\":\"rc522_version\",\"version\":\"0x%02X\"}\n", rc522_version);

    if (rc522_version == 0x91 || rc522_version == 0x92)
    {
        printf("{\"event\":\"rc522_status\",\"status\":\"ok\"}\n");
    }
    else
    {
        printf("{\"event\":\"rc522_status\",\"status\":\"warning\",\"message\":\"unexpected_version_check_wiring\"}\n");
    }

    printf("{\"event\":\"ready\",\"message\":\"waiting_for_badge\"}\n");

    while (1)
    {
        if (RC522_Check(uid) == MI_OK)
        {
            badge_detected = 1;

            uint32_t current_uid = uid_to_u32(uid);
            time_t now = time(NULL);

            int is_new_badge = (!has_last_uid || current_uid != last_uid);
            int delay_expired = (now - last_publish_time) >= SAME_BADGE_DELAY_SECONDS;

            if (is_new_badge || delay_expired)
            {
                print_and_publish_badge(uid);

                last_uid = current_uid;
                last_publish_time = now;
                has_last_uid = 1;
            }

            usleep(200000);
        }
        else
        {
            badge_detected = 0;
            usleep(100000);
        }
    }

    return 0;
}
