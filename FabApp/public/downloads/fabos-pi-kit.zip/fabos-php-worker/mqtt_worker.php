<?php

declare(strict_types=1);

require __DIR__ . '/vendor/autoload.php';

use PhpMqtt\Client\ConnectionSettings;
use PhpMqtt\Client\MqttClient;

// ============================================================
// CONFIGURATION
// ============================================================

$dbHost = getenv('FABOS_DB_HOST') ?: '192.168.0.25';
$dbPort = (int) (getenv('FABOS_DB_PORT') ?: 3306);
$dbName = getenv('FABOS_DB_NAME') ?: 'fabos';
$dbUser = getenv('FABOS_DB_USER') ?: 'fabos';
$dbPass = getenv('FABOS_DB_PASSWORD') ?: (getenv('FABOS_DB_PASS') ?: 'fabos_password');

$mqttHost = getenv('FABOS_MQTT_HOST') ?: (getenv('MQTT_HOST') ?: '127.0.0.1');
$mqttPort = (int) (getenv('FABOS_MQTT_PORT') ?: (getenv('MQTT_PORT') ?: 1883));
$mqttClientId = 'fabos-php-worker-' . uniqid('', true);

$topicBadge = getenv('FABOS_RFID_TOPIC') ?: 'fabos/rfid/badge';
$legacyTopicResult = getenv('FABOS_RESULT_TOPIC') ?: 'fabos/access/result';
$resultTopicPrefix = rtrim($legacyTopicResult, '/') . '/';

$defaultReaderToken = getenv('FABOS_READER_TOKEN') ?: 'reader-printer-01';
$defaultMachineToken = getenv('FABOS_MACHINE_TOKEN') ?: 'printer-01';

// ============================================================
// DATABASE
// ============================================================

try {
    $pdo = new PDO(
        "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset=utf8mb4",
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );

    echo "Connecte a MariaDB {$dbHost}:{$dbPort}, base {$dbName}\n";
} catch (PDOException $e) {
    echo "Erreur connexion MariaDB : {$e->getMessage()}\n";
    exit(1);
}

// ============================================================
// HELPERS
// ============================================================

function normalizeUid(string $uid): string
{
    $uid = strtoupper(trim($uid));

    return preg_replace('/[^A-Z0-9]/', '', $uid) ?? '';
}

function normalizeToken(?string $token): string
{
    return trim((string) $token);
}

function resultTopicForReader(string $resultTopicPrefix, string $readerToken): string
{
    return $resultTopicPrefix . $readerToken;
}

function publishAccessResult(MqttClient $mqtt, string $readerTopic, string $legacyTopic, array $result): void
{
    $json = json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    if ($json === false) {
        $json = '{"authorized":false,"status":"server_error","color":"purple","message":"Erreur encodage JSON"}';
    }

    $mqtt->publish($readerTopic, $json, 0);
    echo "Resultat publie sur {$readerTopic} : {$json}\n";

    // Legacy temporaire: conserve l'ancien topic global pour compatibilite.
    // A supprimer quand toutes les Pi NeoPixel écouteront fabos/access/result/{readerToken}.
    $mqtt->publish($legacyTopic, $json, 0);
    echo "Resultat legacy publie sur {$legacyTopic}\n";
}

function findUserByRfid(PDO $pdo, string $uid): ?array
{
    $stmt = $pdo->prepare("
        SELECT id, firstName, lastName, username, identifiantRfid, statut
        FROM UTILISATEUR
        WHERE identifiantRfid = :uid
        LIMIT 1
    ");
    $stmt->execute([':uid' => $uid]);

    $user = $stmt->fetch();

    return $user ?: null;
}

function findMachineByToken(PDO $pdo, string $machineToken): ?array
{
    $stmt = $pdo->prepare("
        SELECT id, nom, machineToken
        FROM MACHINE
        WHERE machineToken = :machineToken
        LIMIT 1
    ");
    $stmt->execute([':machineToken' => $machineToken]);

    $machine = $stmt->fetch();

    return $machine ?: null;
}

function getRequiredBadges(PDO $pdo, int $machineId): array
{
    $stmt = $pdo->prepare("
        SELECT b.id, b.nom
        FROM MACHINE_BADGE mb
        INNER JOIN BADGE b ON b.id = mb.badgeId
        WHERE mb.machineId = :machineId
          AND mb.requiredForAccess = 1
        ORDER BY b.nom
    ");
    $stmt->execute([':machineId' => $machineId]);

    return $stmt->fetchAll();
}

function getUserBadges(PDO $pdo, int $userId): array
{
    $stmt = $pdo->prepare("
        SELECT b.id, b.nom
        FROM UTILISATEUR_BADGE ub
        INNER JOIN BADGE b ON b.id = ub.badgeId
        WHERE ub.utilisateurId = :userId
        ORDER BY b.nom
    ");
    $stmt->execute([':userId' => $userId]);

    return $stmt->fetchAll();
}

function badgeNames(array $badges): array
{
    return array_values(array_map(static fn (array $badge): string => (string) $badge['nom'], $badges));
}

function findMatchedBadge(array $requiredBadges, array $userBadges): ?array
{
    $ownedBadgeIds = [];

    foreach ($userBadges as $badge) {
        $ownedBadgeIds[(int) $badge['id']] = true;
    }

    foreach ($requiredBadges as $badge) {
        if (isset($ownedBadgeIds[(int) $badge['id']])) {
            return $badge;
        }
    }

    return null;
}

function tableExists(PDO $pdo, string $tableName): bool
{
    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = :tableName
        ");
        $stmt->execute([':tableName' => $tableName]);

        return (int) $stmt->fetchColumn() > 0;
    } catch (Throwable $e) {
        echo "Verification table {$tableName} impossible : {$e->getMessage()}\n";

        return false;
    }
}

function accessLogReaderColumnsExist(PDO $pdo): bool
{
    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = 'ACCESS_RFID_LOG'
              AND COLUMN_NAME IN ('readerId', 'readerToken')
        ");
        $stmt->execute();

        return (int) $stmt->fetchColumn() === 2;
    } catch (Throwable $e) {
        echo "Verification colonnes ACCESS_RFID_LOG lecteur impossible : {$e->getMessage()}\n";

        return false;
    }
}

function findRfidReaderByToken(PDO $pdo, string $readerToken): ?array
{
    if (!tableExists($pdo, 'RFID_READER')) {
        return null;
    }

    $stmt = $pdo->prepare("
        SELECT id, name, readerToken, isActive
        FROM RFID_READER
        WHERE readerToken = :readerToken
        LIMIT 1
    ");
    $stmt->execute([':readerToken' => $readerToken]);

    $reader = $stmt->fetch();

    if (!$reader) {
        echo "Lecteur RFID non déclaré : {$readerToken}\n";

        return null;
    }

    $update = $pdo->prepare("
        UPDATE RFID_READER
        SET lastSeenAt = NOW(), updatedAt = NOW()
        WHERE id = :id
    ");
    $update->execute([':id' => (int) $reader['id']]);

    return $reader;
}

function insertAccessLog(
    PDO $pdo,
    string $badgeUid,
    ?int $userId,
    ?int $machineId,
    ?int $readerId,
    ?string $readerToken,
    bool $authorized,
    string $status,
    string $reason,
    string $message,
    string $color
): void {
    if (accessLogReaderColumnsExist($pdo)) {
        $stmt = $pdo->prepare("
            INSERT INTO ACCESS_RFID_LOG (
                badgeUid,
                userId,
                machineId,
                readerId,
                readerToken,
                authorized,
                status,
                reason,
                message,
                color
            ) VALUES (
                :badgeUid,
                :userId,
                :machineId,
                :readerId,
                :readerToken,
                :authorized,
                :status,
                :reason,
                :message,
                :color
            )
        ");

        $stmt->execute([
            ':badgeUid' => $badgeUid,
            ':userId' => $userId,
            ':machineId' => $machineId,
            ':readerId' => $readerId,
            ':readerToken' => $readerToken,
            ':authorized' => $authorized ? 1 : 0,
            ':status' => $status,
            ':reason' => $reason,
            ':message' => $message,
            ':color' => $color,
        ]);

        return;
    }

    $stmt = $pdo->prepare("
        INSERT INTO ACCESS_RFID_LOG (
            badgeUid,
            userId,
            machineId,
            authorized,
            status,
            reason,
            message,
            color
        ) VALUES (
            :badgeUid,
            :userId,
            :machineId,
            :authorized,
            :status,
            :reason,
            :message,
            :color
        )
    ");

    $stmt->execute([
        ':badgeUid' => $badgeUid,
        ':userId' => $userId,
        ':machineId' => $machineId,
        ':authorized' => $authorized ? 1 : 0,
        ':status' => $status,
        ':reason' => $reason,
        ':message' => $message,
        ':color' => $color,
    ]);
}

function userPayload(?array $user): ?array
{
    if ($user === null) {
        return null;
    }

    $name = trim((string) ($user['firstName'] ?? '') . ' ' . (string) ($user['lastName'] ?? ''));

    if ($name === '') {
        $name = (string) ($user['username'] ?? 'Utilisateur');
    }

    return [
        'id' => (int) $user['id'],
        'name' => $name,
    ];
}

function machinePayload(?array $machine): ?array
{
    if ($machine === null) {
        return null;
    }

    return [
        'id' => (int) $machine['id'],
        'name' => (string) $machine['nom'],
        'token' => (string) $machine['machineToken'],
    ];
}

function baseResult(string $uid, string $readerToken, string $machineToken, ?array $user, ?array $machine, ?array $reader): array
{
    return [
        'uid' => $uid,
        'readerToken' => $readerToken,
        'readerId' => is_array($reader) ? (int) $reader['id'] : null,
        'machineToken' => $machineToken,
        'authorized' => false,
        'status' => 'refused',
        'color' => 'red',
        'message' => 'Acces refuse',
        'user' => userPayload($user),
        'machine' => machinePayload($machine),
        'requiredBadges' => [],
        'userBadges' => [],
        'matchedBadge' => null,
        'timestamp' => gmdate('c'),
    ];
}

function buildAccessResult(PDO $pdo, string $uid, string $readerToken, string $machineToken): array
{
    $reader = findRfidReaderByToken($pdo, $readerToken);
    $machine = findMachineByToken($pdo, $machineToken);

    if (is_array($reader) && (int) $reader['isActive'] === 0) {
        $result = baseResult($uid, $readerToken, $machineToken, null, $machine, $reader);
        $result['status'] = 'reader_inactive';
        $result['reason'] = 'reader_inactive';
        $result['color'] = 'purple';
        $result['message'] = 'Lecteur RFID désactivé';

        return $result;
    }

    $user = findUserByRfid($pdo, $uid);
    $result = baseResult($uid, $readerToken, $machineToken, $user, $machine, $reader);

    if ($user === null) {
        $result['status'] = 'unknown_rfid';
        $result['color'] = 'red';
        $result['message'] = 'Badge RFID inconnu';
        $result['reason'] = 'RFID_NOT_FOUND';

        return $result;
    }

    if (($user['statut'] ?? '') !== 'actif') {
        $result['status'] = 'user_inactive';
        $result['color'] = 'red';
        $result['message'] = 'Utilisateur inactif';
        $result['reason'] = 'USER_INACTIVE';

        return $result;
    }

    if ($machine === null) {
        $result['status'] = 'unknown_machine';
        $result['color'] = 'red';
        $result['message'] = 'Machine inconnue';
        $result['reason'] = 'MACHINE_NOT_FOUND';

        return $result;
    }

    $requiredBadges = getRequiredBadges($pdo, (int) $machine['id']);
    $userBadges = getUserBadges($pdo, (int) $user['id']);
    $matchedBadge = findMatchedBadge($requiredBadges, $userBadges);

    $result['requiredBadges'] = badgeNames($requiredBadges);
    $result['userBadges'] = badgeNames($userBadges);

    if ($requiredBadges === []) {
        $result['authorized'] = true;
        $result['status'] = 'no_badge_required';
        $result['color'] = 'green';
        $result['message'] = 'Aucun badge requis';
        $result['reason'] = 'NO_BADGE_REQUIRED';

        return $result;
    }

    if ($matchedBadge !== null) {
        $result['authorized'] = true;
        $result['status'] = 'authorized';
        $result['color'] = 'green';
        $result['message'] = 'Acces autorise';
        $result['reason'] = 'BADGE_MATCH';
        $result['matchedBadge'] = (string) $matchedBadge['nom'];

        return $result;
    }

    $result['status'] = 'missing_badge';
    $result['color'] = 'orange';
    $result['message'] = 'Badge requis manquant';
    $result['reason'] = 'REQUIRED_BADGE_MISSING';

    return $result;
}

function logResult(PDO $pdo, array $result): void
{
    $userId = is_array($result['user'] ?? null) ? (int) $result['user']['id'] : null;
    $machineId = is_array($result['machine'] ?? null) ? (int) $result['machine']['id'] : null;
    $readerId = isset($result['readerId']) && $result['readerId'] !== null ? (int) $result['readerId'] : null;
    $readerToken = isset($result['readerToken']) && $result['readerToken'] !== '' ? (string) $result['readerToken'] : null;

    insertAccessLog(
        $pdo,
        (string) ($result['uid'] ?? ''),
        $userId,
        $machineId,
        $readerId,
        $readerToken,
        (bool) ($result['authorized'] ?? false),
        (string) ($result['status'] ?? 'server_error'),
        (string) ($result['reason'] ?? ''),
        (string) ($result['message'] ?? ''),
        (string) ($result['color'] ?? 'purple')
    );
}

// ============================================================
// MQTT
// ============================================================

$mqtt = new MqttClient($mqttHost, $mqttPort, $mqttClientId);
$connectionSettings = (new ConnectionSettings())->setKeepAliveInterval(60);

try {
    $mqtt->connect($connectionSettings, true);

    echo "Connecte au broker MQTT {$mqttHost}:{$mqttPort}\n";
    echo "Ecoute du topic : {$topicBadge}\n";
    echo "Publication des resultats sur : {$resultTopicPrefix}{readerToken}\n";
    echo "Publication legacy temporaire sur : {$legacyTopicResult}\n";
    echo "Fallback readerToken si absent : {$defaultReaderToken}\n";
    echo "Fallback machineToken si absent : {$defaultMachineToken}\n";
} catch (Throwable $e) {
    echo "Erreur connexion MQTT : {$e->getMessage()}\n";
    exit(1);
}

$mqtt->subscribe($topicBadge, function (string $topic, string $message) use (
    $pdo,
    $mqtt,
    $resultTopicPrefix,
    $legacyTopicResult,
    $defaultReaderToken,
    $defaultMachineToken
): void {
    echo "\nMessage recu sur {$topic} : {$message}\n";

    $readerToken = $defaultReaderToken;
    $machineToken = $defaultMachineToken;
    $payload = json_decode($message, true);

    if (is_array($payload)) {
        $readerToken = normalizeToken($payload['readerToken'] ?? null) ?: $defaultReaderToken;
        $machineToken = normalizeToken($payload['machineToken'] ?? null) ?: $defaultMachineToken;
    }

    $readerTopic = resultTopicForReader($resultTopicPrefix, $readerToken);

    if (!is_array($payload)) {
        publishAccessResult($mqtt, $readerTopic, $legacyTopicResult, [
            'uid' => null,
            'readerToken' => $readerToken,
            'machineToken' => $machineToken,
            'authorized' => false,
            'status' => 'invalid_payload',
            'reason' => 'INVALID_JSON',
            'message' => 'Message RFID JSON invalide',
            'color' => 'purple',
            'timestamp' => gmdate('c'),
        ]);

        return;
    }

    $uid = normalizeUid((string) ($payload['uid'] ?? ''));

    if ($readerToken === '' || $machineToken === '') {
        publishAccessResult($mqtt, $readerTopic, $legacyTopicResult, [
            'uid' => $uid !== '' ? $uid : null,
            'readerToken' => $readerToken,
            'machineToken' => $machineToken,
            'authorized' => false,
            'status' => 'invalid_payload',
            'reason' => 'TOKEN_MISSING',
            'message' => 'readerToken ou machineToken manquant',
            'color' => 'purple',
            'timestamp' => gmdate('c'),
        ]);

        return;
    }

    if ($uid === '') {
        publishAccessResult($mqtt, $readerTopic, $legacyTopicResult, [
            'uid' => null,
            'readerToken' => $readerToken,
            'machineToken' => $machineToken,
            'authorized' => false,
            'status' => 'invalid_payload',
            'reason' => 'UID_MISSING',
            'message' => 'UID RFID manquant',
            'color' => 'purple',
            'timestamp' => gmdate('c'),
        ]);

        return;
    }

    try {
        $result = buildAccessResult($pdo, $uid, $readerToken, $machineToken);
        logResult($pdo, $result);
        publishAccessResult($mqtt, $readerTopic, $legacyTopicResult, $result);
    } catch (Throwable $e) {
        echo "Erreur traitement badge : {$e->getMessage()}\n";

        $result = [
            'uid' => $uid,
            'readerToken' => $readerToken,
            'machineToken' => $machineToken,
            'authorized' => false,
            'status' => 'server_error',
            'reason' => 'EXCEPTION',
            'message' => 'Erreur serveur',
            'color' => 'purple',
            'timestamp' => gmdate('c'),
        ];

        try {
            insertAccessLog($pdo, $uid, null, null, null, $readerToken, false, 'server_error', 'EXCEPTION', $e->getMessage(), 'purple');
        } catch (Throwable $logError) {
            echo "Erreur log RFID : {$logError->getMessage()}\n";
        }

        publishAccessResult($mqtt, $readerTopic, $legacyTopicResult, $result);
    }
}, 0);

$mqtt->loop(true);
