# Installation du kit FABOS Pi

Ce guide décrit l'installation du kit Raspberry Pi FABOS sur une Pi cible. Le kit est portable : il n'impose pas que l'utilisateur Linux s'appelle `subhen`.

## Chemins

Copiez le kit dans le dossier personnel de l'utilisateur qui lancera FABOS, par exemple :

- `/home/pi`
- `/home/fabos`
- `/home/<utilisateur>`

Les scripts utilisent `$HOME` par défaut. Si le kit est installé dans un autre dossier, forcez le chemin avec `FABOS_HOME` :

```sh
FABOS_HOME=/home/fabos ./start_fabos.sh
```

## Fichiers attendus

Le dossier d'installation doit contenir :

- `fabos-rfid/`
- `fabos-neopixel-test/`
- `fabos-php-worker/`
- `start_fabos.sh`
- `stop_fabos.sh`
- `fabos-device.env.example`
- `README_SETUP_PI.md`

## Configuration de la Pi

Créez le vrai fichier de configuration depuis le modèle :

```sh
cp $HOME/fabos-device.env.example $HOME/fabos-device.env
nano $HOME/fabos-device.env
```

`fabos-device.env.example` est seulement un modèle. Il montre les variables nécessaires, mais il ne doit pas être utilisé tel quel. Collez dans `$HOME/fabos-device.env` la configuration générée par l'admin FABOS pour le lecteur RFID concerné.

Exemple :

```sh
FABOS_READER_TOKEN=reader-printer-01
FABOS_MACHINE_TOKEN=printer-01
MQTT_HOST=127.0.0.1
MQTT_PORT=1883
FABOS_DB_HOST=192.168.88.229
FABOS_DB_PORT=3306
FABOS_DB_NAME=fabos
FABOS_DB_USER=fabos
FABOS_DB_PASSWORD=fabos_password
```

`FABOS_DB_HOST` doit être l'adresse IP du PC/serveur où tourne MariaDB. Si vous changez de Wi-Fi, cette IP peut changer. Vérifiez-la avec `hostname -I` sur le PC.

## Droits d'exécution

```sh
chmod +x $HOME/start_fabos.sh
chmod +x $HOME/stop_fabos.sh
chmod +x $HOME/fabos-rfid/fabos-rfid
chmod +x $HOME/fabos-neopixel-test/fabos-neopixel-mqtt
```

## Recompilation sur la Pi cible

Recompilez les programmes natifs sur la Raspberry Pi cible. Un binaire compilé sur une autre machine peut ne pas fonctionner.

```sh
cd $HOME/fabos-rfid
make clean
make
chmod +x fabos-rfid

cd $HOME/fabos-neopixel-test
make clean
make
chmod +x fabos-neopixel-mqtt
```

## Lancement

```sh
cd $HOME
./stop_fabos.sh
./start_fabos.sh
```

Vérifiez les processus :

```sh
ps aux | grep -E "fabos-rfid|mqtt_worker|fabos-neopixel" | grep -v grep
```

Suivez les logs :

```sh
tail -f $HOME/fabos-rfid.log
tail -f $HOME/fabos-php-worker.log
tail -f $HOME/fabos-neopixel.log
```

## Contenu du zip du kit

Le zip du kit peut contenir :

- `fabos-rfid/`
- `fabos-neopixel-test/`
- `fabos-php-worker/`
- `start_fabos.sh`
- `stop_fabos.sh`
- `fabos-device.env.example`
- `README_SETUP_PI.md`

Le zip du kit ne doit pas contenir :

- `fabos-device.env` réel
- fichiers `.log`
- binaires compilés si on veut un kit portable
- dossiers `.git` internes comme `rpi_ws281x/.git`
- fichiers `.o`, `.a`, `__pycache__`
